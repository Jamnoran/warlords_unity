"First-person Demo" level uses Unity's standard character wich was removed from the package to avoid file conflicts (and also is an Asset Store requirement).

To make the level work properly, you just need to import a 1-s person character back (Assets -> Import Package -> Characters).

Standard assets are also available on the Asset Store: https://www.assetstore.unity3d.com/#!/content/32351